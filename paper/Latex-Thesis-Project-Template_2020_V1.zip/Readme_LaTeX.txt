To get this template up and running, you have two options:

1. Run it offline
    For this option, we can recommend the following applications:

    - MiKTeX (A LaTeX typesetting system), which is assembling LaTex code to documents
        URL:   https://miktex.org/download

    - Text studio (A LaTex editor), which you will need as IDE
        URL:   https://www.texstudio.org/

    You need both in order to get LaTex up and running.

2. Run it in the cloud
    For this option we would recommend Overleaf.com, which provides you a free LaTex environment. 